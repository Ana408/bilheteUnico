 <?php
include_once('inicio/admin/config/config.php');
 ?>
<!DOCTYPE html>
<html lang="pt-BR utf-8">
  <head>
    <title>Bilhete Único</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800|DM+Serif+Display:400,400i&display=swap" rel="stylesheet">

    <link rel="shortcut icon" href="ftco-32x32.png">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">

    <link rel="stylesheet" href="inicio/css/bootstrap.css">
    <link rel="stylesheet" href="inicio/css/animate.css">
    <link rel="stylesheet" href="inicio/css/owl.carousel.min.css">
    <link rel="stylesheet" href="inicio/css/aos.css">

    <link rel="stylesheet" href="inicio/css/magnific-popup.css">


    <link rel="stylesheet" href="inicio/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="inicio/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="inicio/fonts/flaticon/font/flaticon.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="inicio/css/style.css">
    
  </head>
  <body>
    
    <header role="banner">
      <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="index.php">Bilhete Único</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarsExample05">
            <ul class="navbar-nav ml-auto pl-lg-5 pl-0">
              <li class="nav-item">
                <a class="nav-link" href="index.php"><strong>Home</strong> </a>
              </li>
            </ul>

            
            
          </div>
        </div>
      </nav>
    </header>
    <!-- END header -->
    
    <div class="slider-wrap">

      <section class="home-slider owl-carousel">
        <?php
                $select = "SELECT * FROM tb_slide ORDER BY id_slide DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
        <div class="slider-item" style="background-image: url('inicio/admin/img/slide/<?php echo $show->img_slide; ?>');" >
          
          <div class="container">
            <div class="row slider-text align-items-center justify-content-center">
              <div class="col-md-8 text-center col-sm-12 ">
                <h1 style="font-size: 65px" data-aos="fade-up mb-5"><?php echo $show->nome_slide; ?></h1>
                <p data-aos="fade-up" data-aos-delay="200"><a href="<?php echo $show->link; ?>" class="btn btn-white btn-outline-white">Veja</a></p>
               </div>
            </div>
          </div>
        </div>
        <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
       
      </section>
    <!-- END slider -->
    </div> 

        <section class="section bg-light py-5  bottom-slant-gray">
       <div class="container">
        <div class="col-md-4 mb-5">
            <h3>Cadrastre-se</h3>
          </div>
      <form method="post">
        <div class="form-group">
    <label for="exampleInputEmail1">Nome</label>
    <input type="text" class="form-control" name="nome" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu Nome completo">
    <br>
  <div class="form-group">
    <label for="exampleInputEmail1">Endereço de email</label>
    <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu email">
    <small id="emailHelp" class="form-text text-muted">Nunca vamos compartilhar seu email, com ninguém.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Senha</label>
    <input type="password" class="form-control" name="senha" id="exampleInputPassword1" placeholder="Senha">
  </div>
  
  <button type="submit" name="cadrastro" class="btn btn-primary">Enviar</button>
</form>
           <?php
                                  include_once('inicio/admin/config/conect.php');
                                  if (isset($_POST['cadrastro'])) {
                                    $nome = $_POST['nome'];
                                    $email = $_POST['email'];
                                    $senha = $_POST['senha'];
                                    
                                    # criação da variável 'insert' com o valor de query SQL(código do banco de dados)
                                    $insert = "INSERT INTO tb_cad (nome_cad, email_cad, senha) VALUES (:nome,:email,:senha)";
                                    try {
                                    # proteção contra o SQL Inject
                                    $result = $con->prepare($insert);
                                    $result->bindParam(':nome', $nome, PDO::PARAM_STR);
                                    $result->bindParam(':email', $email, PDO::PARAM_STR);
                                    $result->bindParam(':senha', $senha, PDO::PARAM_INT);
                                    $result->execute();

                                    $contar = $result->rowCount();
                                  if ($contar > 0) {
                                    echo '<div class="alert alert-success alert-dismissible" style="margin-bottom:0;padding:6px 35px;margin-top:10px;">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-check"></i>Seus Últimos Dados Foram Cadastrados com Sucesso!
                                          </div>';
                                           
                                  }else {
                                    echo '<div class="alert alert-danger alert-dismissible" style="margin-bottom:0;padding:6px 35px">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-warning"></i>Seus Últimos Dados Não Foram Cadastrados!
                                          </div';
                                  }
                                }catch (PDOException $e) {
                                  echo "ERRO de PDO:: $e";
                                }
                              }
                                  ?>
                              <!-- Fim Cadastro PHP -->

</div>
    </section>

    <section class="section bg-light py-5  bottom-slant-gray">
     
      <div class="container">
         <?php
                $select = "SELECT * FROM tb_desc ORDER BY id_desc DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
        <div class="row align-items-center">

          <div class="col-lg-6">
            <img src="inicio/admin/img/descricao/<?php echo $show->img_desc; ?>" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-5 ml-auto">
            <div class="text-left heading-wrap">
              <h2 data-aos="fade-up"><?php echo $show->titulo_desc; ?></h2>
            </div>
            
            <p><?php echo $show->descr; ?></p>
            
          </div>
          
        </div>
        <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
      </div>
      
    </section>
    

    <footer class="site-footer" role="contentinfo">
      
      <div class="container">
        <?php
                $select = "SELECT * FROM tb_rodape ORDER BY id_rodape DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar3336-6169 os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {
          
                    ?>
        <div class="row mb-5">
          <div class="col-md-4 mb-5">
            <h3><?php echo $show->titulo; ?></h3>
            <p class="mb-5"><?php echo $show->des; ?></p>
            

          </div>
          <div class="col-md-5 mb-5">
            <div class="mb-5">
              <h3>Horário</h3>
              <p><strong class="d-block font-weight-normal text-black">Segunda á Sexta</strong> <?php echo $show->horario; ?> as <?php echo $show->hora_fecha; ?></p>
            </div>
            <div>
              <h3 style="margin-top: -10px;">Contato</h3>
              <ul class="list-unstyled footer-link">
                <li class="d-block">
                  <span class="d-block text-black">Endereço:</span>
                  <span><?php echo $show->endereco; ?></span></li>
                <li class="d-block"><span class="d-block text-black">Telefone:</span><span><?php echo $show->telefone; ?></span></li>
              
              </ul>
            </div>
          </div>
          
          <div class="col-md-3">
          
          </div>
        </div>
        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> - SindiÔnibus 2021 - <i class="fa fa-heart-o" aria-hidden="true"></i> 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->

            </p>
          </div>
        </div>
        <?php
               }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há Materiais cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
      </div>
    </footer>
    <!-- END footer -->

    <!-- loader -->
    <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#cf1d16"/></svg></div>

    <script src="inicio/js/jquery-3.2.1.min.js"></script>
    <script src="inicio/js/popper.min.js"></script>
    <script src="inicio/js/bootstrap.min.js"></script>
    <script src="inicio/js/owl.carousel.min.js"></script>
    <script src="inicio/js/jquery.waypoints.min.js"></script>
    <script src="inicio/js/aos.js"></script>

    <script src="inicio/js/jquery.magnific-popup.min.js"></script>
    <script src="inicio/js/magnific-popup-options.js"></script>
    

    <script src="inicio/js/main.js"></script>
    
  </body>
</html>



