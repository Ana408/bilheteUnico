 <div id="content-wrapper">

      <div class="container-fluid">
<ol class="breadcrumb">
          <li class="breadcrumb-item active">Rodapé</li>
        </ol>

       
        <hr>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<div class="row">

     <div class="col-lg-6">
      <form  method="post">
       <div class="form-group">
         <label for="titulo">Titulo (Descrição)</label>
        <input type="text" class="form-control" name="titulo" id="titulo" placeholder="Titulo" >
       </div>
        <div class="form-group">
         <label for="desc1">Descrição</label>
          <textarea class="form-control" name="des" id="des" placeholder="Descrição"></textarea>
       </div>
        <div class="form-group">
         <label for="hora">Horário de Abertura</label>
          <input type="text" class="form-control" name="hora" id="hora" placeholder="Horário de Aberura" >
       </div>
       <div class="form-group">
         <label for="horaE">Hora de Encerrar</label>
          <input type="text" class="form-control" name="horaE" id="horaE" placeholder="Horário de Encerramento" >
       </div>
        <div class="form-group">
         <label for="endereco">Endereço</label>
          <input type="text" class="form-control" name="endereco" id="endereco" placeholder="Endereço">
       </div>
        <div class="form-group">
         <label for="telefone">Telefone</label>
          <input type="text" class="form-control" name="telefone" id="telefone" placeholder="Telefone" >
       </div>
        
        <div class="row">
       <div class="col-lg-4">
         <button class="btn btn-success" type="submit" name="rodape">Enviar</button>
       </div></div>
        </form>
        <?php
                                  include_once('config/conect.php');
                                  if (isset($_POST['rodape'])) {
                                    $titulo = $_POST['titulo'];
                                    $desc = $_POST['des'];
                                    $horario = $_POST['hora'];
                                    $hora = $_POST['horaE'];
                                    $end = $_POST['endereco'];
                                    $tel = $_POST['telefone'];
                                    
                                    
                                    
                                    # criação da variável 'insert' com o valor de query SQL(código do banco de dados)
                                    $insert = "INSERT INTO tb_rodape (titulo, des, horario,hora_fecha, endereco,telefone) VALUES (:titulo,:des,:hora,:horaE,:endereco,:telefone)";
                                    try {
                                    # proteção contra o SQL Inject
                                    $result = $con->prepare($insert);
                                    $result->bindParam(':titulo', $titulo, PDO::PARAM_STR);
                                    $result->bindParam(':des', $desc, PDO::PARAM_STR);
                                    $result->bindParam(':hora', $horario, PDO::PARAM_INT);
                                    $result->bindParam(':horaE', $hora, PDO::PARAM_INT);
                                    $result->bindParam(':endereco', $end, PDO::PARAM_STR);
                                    $result->bindParam(':telefone', $tel, PDO::PARAM_STR);
                                   
                                    $result->execute();

                                    $contar = $result->rowCount();
                                  if ($contar > 0) {
                                    echo '<div class="alert alert-success alert-dismissible" style="margin-bottom:0;padding:6px 35px;margin-top:10px;">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-check"></i>Seus Últimos Dados Foram Cadastrados com Sucesso!
                                          </div>';
                                           header("location: home.php?acaoadmin=rodape");
                                  }else {
                                    echo '<div class="alert alert-danger alert-dismissible" style="margin-bottom:0;padding:6px 35px">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-warning"></i>Seus Últimos Dados Não Foram Cadastrados!
                                          </div';
                                  }
                                }catch (PDOException $e) {
                                  echo "ERRO de PDO:: $e";
                                }
                              }
                                  ?>
                              <!-- Fim Cadastro PHP -->

                    
                    
                    
                       
     
     
</div>
</div>
</div>
</div>
</div>
</div>


 <br>  
        <div class="col-lg-12">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Rodapé</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Titulo (Descrição)</th>
                    <th>Descrição</th>
                    <th>Horário de Abertura</th>
                     <th>Horário de Encerrar</th>
                    <th>Endereço</th>
                    <th>Telefone</th>
                   
                    <th>Editar</th>
                    <th>Remover</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                $select = "SELECT * FROM tb_rodape ORDER BY id_rodape DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td> <?php echo $show->id_rodape; ?></td>
                    <td> <?php echo $show->titulo; ?></td>
                    <td> <?php echo $show->des; ?></td>
                    <td> <?php echo $show->horario; ?></td>
                    <td> <?php echo $show->hora_fecha; ?></td>
                    <td> <?php echo $show->endereco; ?></td>
                    <td> <?php echo $show->telefone; ?></td>
                    
                    <td>
              <a href="home.php?acaoadmin=Uprodape&editar=<?php echo $show->id_rodape; ?>" class="btn btn-primary" title="Atualizar">
                                              <i class="far fa-edit"></i>
                                            </a></td>
       <td><a href="paginas/delete/delete.php?idDel4=<?php echo $show->id_rodape; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                  
                    
                  </tr>
                 <?php
               }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há Materiais cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>


      </div>
      <!-- /.container-fluid -->