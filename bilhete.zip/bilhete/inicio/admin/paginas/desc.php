 <div id="content-wrapper">

      <div class="container-fluid">

<ol class="breadcrumb">
          <li class="breadcrumb-item active">Descrição</li>
        </ol>
        <!-- Page Content -->
        
        <hr>
        <div class="row">
          <div class="col-lg-12">
        <div class="card">
  <div class="card-body">
   <div class="row">

     <div class="col-lg-6">
      <form method="post" enctype="multipart/form-data">
       <div class="form-group">
         <label for="foto">Imagem</label>
       <input type="file" class="form-control" name="foto[]" id="foto" placeholder="" >
       </div>
        <div class="form-group">
         <label for="titulo">Titulo</label>
          <input type="text" class="form-control" name="titulo" placeholder="Titulo" >
       </div>
        <div class="form-group">
         <label for="descr">Descrição</label>
          <textarea type="text" class="form-control valid" name="descri" id="descri" placeholder="Descrição"></textarea> 
       </div>
       <div class="row">
       <div class="col-lg-4">
         <button class="btn btn-success" type="submit" name="descr">Enviar</button>
       </div>
        </div>
          </form>
                <?php
             
                  if (isset($_POST['descr'])) {

                    $nome = trim(strip_tags($_POST['titulo']));
                    $email = trim(strip_tags($_POST['descri']));
                    
        //INFO IMAGEM
        $file = $_FILES['foto'];
        $numFile  = count(array_filter($file['name']));

        //PASTA
        $folder   = 'img/descricao';

        //REQUISITOS
        $permite  = array('image/jpeg', 'image/png', 'image/jpg', 'image/gif');
        $maxSize  = 1024 * 1024 * 2;

        //MENSAGENS
        $msg    = array();
        $errorMsg = array(
      1 => 'O arquivo no upload é maior do que o limite definido em upload_max_filesize no php.ini.',
      2 => 'O arquivo ultrapassa o limite de tamanho em MAX_FILE_SIZE que foi especificado no formulário HTML',
      3 => 'o upload do arquivo foi feito parcialmente',
      4 => 'Não foi feito o upload do arquivo'
        );
        if($numFile <= 0){
          echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                Selecione uma foto para avatar do usuário!
              </div>';
        }else if($numFile >=2){
          echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                Seu limite e de uma foto de avatar apenas.
              </div>';
        }else{
          for($i = 0; $i < $numFile; $i++){
          //Todos os dados referentes ao array de imagem
            $name = $file['name'][$i]; //nome da imagem
            $type = $file['type'][$i]; //tipo da imagem (jpg,png....)
            $size = $file['size'][$i]; //tamanho da imagem
            $error = $file['error'][$i]; //mensagem de erro da imagem
            $tmp  = $file['tmp_name'][$i]; //caminho da imagem no meu dispositivo

            //tratamentoda extenção do meu arquivo(imagem)
            $extensao = @end(explode('.', $name));
            $novoNome = rand().".$extensao";

            if($error != 0)
              $msg[] = "<b>$name :</b> ".$errorMsg[$error];
            else if(!in_array($type, $permite))
              $msg[] = "<b>$name :</b> Erro imagem não suportada!";
            else if($size > $maxSize)
              $msg[] = "<b>$name :</b> Erro imagem ultrapassa o limite de 2MB";
            else{

                if(move_uploaded_file($tmp, $folder.'/'.$novoNome)){
                  $insert = "INSERT INTO tb_desc (img_desc,titulo_desc,descr) VALUES (:foto, :titulo, :descri)";
                  try {
                  # proteção contra o SQL Inject
                  $result = $con->prepare($insert);
                  $result->bindParam(':foto', $novoNome, PDO::PARAM_STR);
                  $result->bindParam(':titulo', $nome, PDO::PARAM_STR);
                  $result->bindParam(':descri', $email, PDO::PARAM_STR);
                  
                  $result->execute();


                 $contar = $result->rowCount();
                    if ($contar > 0) {
                       echo '<div class="alert alert-success alert-dismissible" style="margin-bottom:0;padding:6px 35px;margin-top:10px;">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-check"></i>Seus Últimos Dados Foram Cadastrados com Sucesso!
                                          </div>';
                      #header("Refresh: 3, home.php?acaoadmin=email");
                    }else {
                      echo '<div class="alert alert-danger alert-dismissible" style="margin-bottom:0;padding:6px 35px;margin-top:10px;">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-warning"></i>Seus Últimos Dados Não Foram Cadastrados!
                                          </div';
                    }
                  }catch (PDOException $e) {
                    echo "ERRO de PDO:: $e";
                    }
                 }else
                   $msg[] = "<b>$name :</b> Desculpe! Ocorreu um erro dados não enviados...";
               }
            }
         }

       
                  }

                ?>

</div>
</div>
</div>
</div>
</div>
</div>
</div>

<br>
 <!-- DataTables Example -->
        <div class="col-lg-12">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Descrição</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Imagem</th>
                    <th>Titulo</th>
                    <th>Descrição</th>
                    <th>Editar</th>
                    <th>Remover</th>
                     </tr>
                </thead>
               <tbody>
                 <?php
                $select = "SELECT * FROM tb_desc ORDER BY id_desc DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td><?php echo $show->id_desc; ?></td>
                    <td><img src="img/descricao/<?php echo $show->img_desc; ?>" style="width:130px"/></td>
                    <td><?php echo $show->titulo_desc; ?></td>
                    <td><?php echo $show->descr; ?></td>
                    <td>
              <a href="home.php?acaoadmin=Updesc&editar=<?php echo $show->id_desc; ?>" class="btn btn-primary" data-dismiss="modal" title="Atualizar">
                                               <i class="far fa-edit"></i>
                                            </a></td>
       <td><a href="paginas/delete/delete.php?idDel2=<?php echo $show->id_desc; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                    </td>
                    
                  </tr>
                 <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>

      </div>
      <!-- /.container-fluid -->