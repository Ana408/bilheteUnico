 <div id="content-wrapper">

      <div class="container-fluid">
<ol class="breadcrumb">
          <li class="breadcrumb-item active">Usuários do Bilhete Único</li>
        </ol>
        <hr>    
</div>
<br>     
<div class="col-lg-12">
  <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Usuários</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nome</th>
                    
                    <th>Email</th>
                    <th>Senha</th>
                    
                    <th>Remover</th>
                  </tr>
                </thead>
                <tbody>
                   <?php
                $select = "SELECT * FROM tb_cad ORDER BY id_cad DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td><?php echo $show->id_cad; ?></td>
                    <td><?php echo $show->nome_cad; ?>"</td>
                    <td><?php echo $show->email_cad; ?></td>
                    <td><?php echo $show->senha; ?></td>
                     
       <td><a href="paginas/delete/delete.php?idDel3=<?php echo $show->id_sistema; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                    
                    
                  </tr>
                 <?php
              }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          </div>
        </div>



      </div>
      <!-- /.container-fluid -->