<div id="content-wrapper">

      <div class="container-fluid">
       <ol class="breadcrumb">
          <li class="breadcrumb-item active">Slide</li>
        </ol>
        <hr>
  <div class="row">
  <div class="col-lg-12">
  <div class="card">
  <div class="card-body">
   <div class="row">

     <div class="col-lg-12">
      <form method="post"  enctype="multipart/form-data">
       <div class="form-group">
         <label for="slide">Imagem</label>
        <input type="file" class="form-control" name="slide[]" id="slide" placeholder="" >

       </div>
        <div class="form-group">
         <label for="titulo">Titulo</label>
          <input type="text" class="form-control" name="titulo" id="titulo" placeholder="Titulo" >
       </div>
       <div class="form-group">
         <label for="titulo">Link</label>
          <input type="text" class="form-control" name="link" id="link" placeholder="Link" >
       </div>
       <div class="row">
       <div class="col-lg-6">
         <button class="btn btn-success" type="submit" name="enviar">Enviar</button>
       </div>
         </div>
          </div>
        </form>
           <?php

                  if (isset($_POST['enviar'])) {
             $nome = trim(strip_tags($_POST['titulo']));
             $link = trim(strip_tags($_POST['link']));
             //INFO IMAGEM
        $file = $_FILES['slide'];
        $numFile  = count(array_filter($file['name']));

        //PASTA
        $folder   = 'img/slide';

        //REQUISITOS
        $permite  = array('image/jpeg', 'image/png', 'image/jpg', 'image/gif');
        $maxSize  = 1024 * 1024 * 2;

        //MENSAGENS
        $msg    = array();
        $errorMsg = array(
      1 => 'O arquivo no upload é maior do que o limite definido em upload_max_filesize no php.ini.',
      2 => 'O arquivo ultrapassa o limite de tamanho em MAX_FILE_SIZE que foi especificado no formulário HTML',
      3 => 'o upload do arquivo foi feito parcialmente',
      4 => 'Não foi feito o upload do arquivo'
        );
        if($numFile <= 0){
          echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                Selecione uma foto para avatar do usuário!
              </div>';
        }else if($numFile >=2){
          echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                Seu limite e de uma foto de avatar apenas.
              </div>';
        }else{
          for($i = 0; $i < $numFile; $i++){
          //Todos os dados referentes ao array de imagem
            $name = $file['name'][$i]; //nome da imagem
            $type = $file['type'][$i]; //tipo da imagem (jpg,png....)
            $size = $file['size'][$i]; //tamanho da imagem
            $error = $file['error'][$i]; //mensagem de erro da imagem
            $tmp  = $file['tmp_name'][$i]; //caminho da imagem no meu dispositivo

            //tratamentoda extenção do meu arquivo(imagem)
            $extensao = @end(explode('.', $name));
            $novoNome = rand().".$extensao";

            if($error != 0)
              $msg[] = "<b>$name :</b> ".$errorMsg[$error];
            else if(!in_array($type, $permite))
              $msg[] = "<b>$name :</b> Erro imagem não suportada!";
            else if($size > $maxSize)
              $msg[] = "<b>$name :</b> Erro imagem ultrapassa o limite de 2MB";
            else{

                if(move_uploaded_file($tmp, $folder.'/'.$novoNome)){
                  $insert = "INSERT INTO tb_slide (img_slide, nome_slide,link) VALUES (:slide,:titulo,:link)";
                  try {
                  # proteção contra o SQL Inject
                  $result = $con->prepare($insert);
                  $result->bindParam(':slide', $novoNome, PDO::PARAM_STR);
                  $result->bindParam(':titulo', $nome, PDO::PARAM_STR);
                   $result->bindParam(':link', $link, PDO::PARAM_STR);
                  
                  $result->execute();


                 $contar = $result->rowCount();
                    if ($contar > 0) {
                       echo '<div class="alert alert-success alert-dismissible" style="margin-bottom:0;padding:6px 35px;margin-top:10px;">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-check"></i>Seus Últimos Dados Foram Cadastrados com Sucesso!
                                          </div>';
                      #header("Refresh: 3, home.php?acaoadmin=email");
                    }else {
                      echo '<div class="alert alert-danger alert-dismissible" style="margin-bottom:0;padding:6px 35px;margin-top:10px;">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-warning"></i>Seus Últimos Dados Não Foram Cadastrados!
                                          </div';
                    }
                  }catch (PDOException $e) {
                    echo "ERRO de PDO:: $e";
                    }
                 }else
                   $msg[] = "<b>$name :</b> Desculpe! Ocorreu um erro dados não enviados...";
               }
            }
         }


                  }
                ?>
      
</div>
</div>
</div>
</div>
</div>

<br>
<!-- DataTables Example -->
        <div class="col-lg-12">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Slide</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Imagem</th>
                    <th>Nome (Sistemas)</th>
                    <th>Link</th>
                    <th>Editar</th>
                    <th>Remover</th>
                  </tr>
                </thead>
               <tbody>
                <?php
                $select = "SELECT * FROM tb_slide ORDER BY id_slide DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td><?php echo $show->id_slide; ?></td>
                    <td><img src="img/slide/<?php echo $show->img_slide; ?>" style="width:90px"/></td>
                    <td><?php echo $show->nome_slide; ?></td>
                    <td><?php echo $show->link; ?></td>
                      <td>
              <a href="home.php?acaoadmin=UpSlide&editar=<?php echo $show->id_slide; ?>" class="btn btn-primary" data-dismiss="modal" title="Atualizar">
                                              <i class="far fa-edit"></i>
                                            </a></td>
       <td><a href="paginas/delete/delete.php?idDel=<?php echo $show->id_slide; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                    </td>
                  </tr>
                 <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
        </div>
      </div>
      <!-- /.container-fluid -->