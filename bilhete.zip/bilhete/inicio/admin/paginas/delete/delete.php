<?php

include_once('../../config/config.php');
if (isset($_GET['idDel'])) {
  $id = $_GET['idDel'];
  $delete = "DELETE FROM tb_slide WHERE id_slide=:id";

  try{
    $result = $con->prepare($delete);
    $result->bindValue(':id',$id,PDO::PARAM_INT);
    $result->execute();

    $contar=$result->rowCount();
    if ($contar>0) {
      header("Location: ../../home.php?acaoadmin=Slide");
    }else{
      header("Location: ../../home.php?acaoadmin=Slide");
    }
  }catch(PDOException $e){
    echo "<b>ERRO DE DELETE: </b>".$e->getMessage();
  }
}

if (isset($_GET['idDel2'])) {
  $id = $_GET['idDel2'];
  $delete = "DELETE FROM tb_desc WHERE id_desc=:id";

  try{
    $result = $con->prepare($delete);
    $result->bindValue(':id',$id,PDO::PARAM_INT);
    $result->execute();

    $contar=$result->rowCount();
    if ($contar>0) {
      header("Location: ../../home.php?acaoadmin=desc");
    }else{
      header("Location: ../../home.php?acaoadmin=desc");
    }
  }catch(PDOException $e){
    echo "<b>ERRO DE DELETE: </b>".$e->getMessage();
  }
}

if (isset($_GET['idDel3'])) {
  $id = $_GET['idDel3'];
  $delete = "DELETE FROM tb_sistemas WHERE id_sistema=:id";

  try{
    $result = $con->prepare($delete);
    $result->bindValue(':id',$id,PDO::PARAM_INT);
    $result->execute();

    $contar=$result->rowCount();
    if ($contar>0) {
      header("Location: ../../home.php?acaoadmin=sistema");
    }else{
      header("Location: ../../home.php?acaoadmin=sistema");
    }
  }catch(PDOException $e){
    echo "<b>ERRO DE DELETE: </b>".$e->getMessage();
  }
}

if (isset($_GET['idDel4'])) {
  $id = $_GET['idDel4'];
  $delete = "DELETE FROM tb_rodape WHERE id_rodape=:id";

  try{
    $result = $con->prepare($delete);
    $result->bindValue(':id',$id,PDO::PARAM_INT);
    $result->execute();

    $contar=$result->rowCount();
    if ($contar>0) {
      header("Location: ../../home.php?acaoadmin=rodape");
    }else{
      header("Location: ../../home.php?acaoadmin=rodape");
    }
  }catch(PDOException $e){
    echo "<b>ERRO DE DELETE: </b>".$e->getMessage();
  }
}

if (isset($_GET['idDel5'])) {
  $id = $_GET['idDel5'];
  $delete = "DELETE FROM tb_user WHERE id_user=:id";

  try{
    $result = $con->prepare($delete);
    $result->bindValue(':id',$id,PDO::PARAM_INT);
    $result->execute();

    $contar=$result->rowCount();
    if ($contar>0) {
      header("Location: ../../home.php?acaoadmin=user");
    }else{
      header("Location: ../../home.php?acaoadmin=user");
    }
  }catch(PDOException $e){
    echo "<b>ERRO DE DELETE: </b>".$e->getMessage();
  }
}