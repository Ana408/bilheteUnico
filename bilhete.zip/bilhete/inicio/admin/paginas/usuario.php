 <div id="content-wrapper">

      <div class="container-fluid">
<ol class="breadcrumb">
          <li class="breadcrumb-item active">Usuários</li>
        </ol>

       
        <hr>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<div class="row">

     <div class="col-lg-6">
      <form  method="post">
       <div class="form-group">
         <label for="nome">Nome</label>
        <input type="text" class="form-control" name="nome" id="nome" placeholder="Nome" maxlength="100">
       </div>
        <div class="form-group">
         <label for="email">E-mail</label>
          <input class="form-control" name="email" id="email" placeholder="E-mail"></input>
       </div>
        <div class="form-group">
         <label for="telefone">Telefone</label>
          <input type="text" class="form-control" name="telefone" id="telefone" placeholder="Telefone" maxlength="100">
       </div>
       <div class="form-group">
         <label for="senha">Senha</label>
          <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha" maxlength="100">
       </div>
        <div class="row">
       <div class="col-lg-4">
         <button class="btn btn-success" type="submit" name="user">Enviar</button>
       </div></div>
        </form>
        <?php
                                  include_once('config/conect.php');
                                  if (isset($_POST['user'])) {
                                    $titulo = $_POST['nome'];
                                    $desc = $_POST['email'];
                                    $horario = $_POST['telefone'];
                                    $hora = $_POST['senha'];
                                    
                                    
                                    
                                    # criação da variável 'insert' com o valor de query SQL(código do banco de dados)
                                    $insert = "INSERT INTO tb_user (nome,email,telefone,senha) VALUES (:nome,:email,:telefone,:senha)";
                                    try {
                                    # proteção contra o SQL Inject
                                    $result = $con->prepare($insert);
                                    $result->bindParam(':nome', $titulo, PDO::PARAM_STR);
                                    $result->bindParam(':email', $desc, PDO::PARAM_STR);
                                    $result->bindParam(':telefone', $horario, PDO::PARAM_INT);
                                    $result->bindParam(':senha', $hora, PDO::PARAM_INT);
                                    $result->execute();

                                    $contar = $result->rowCount();
                                  if ($contar > 0) {
                                    echo '<div class="alert alert-success alert-dismissible" style="margin-bottom:0;padding:6px 35px;margin-top:10px;">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-check"></i>Seus Últimos Dados Foram Cadastrados com Sucesso!
                                          </div>';
                                           header("location: home.php?acaoadmin=user");
                                  }else {
                                    echo '<div class="alert alert-danger alert-dismissible" style="margin-bottom:0;padding:6px 35px">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <i class="icon fa fa-warning"></i>Seus Últimos Dados Não Foram Cadastrados!
                                          </div';
                                  }
                                }catch (PDOException $e) {
                                  echo "ERRO de PDO:: $e";
                                }
                              }
                                  ?>
                              <!-- Fim Cadastro PHP -->

                    
                    
                    
                       
     
     
</div>
</div>
</div>
</div>
</div>
</div>


 <br>  
        <div class="col-lg-12">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Rodapé</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Senha</th>
                     <th>Telefone</th>
                    <th>Editar</th>
                    <th>Remover</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                $select = "SELECT * FROM tb_user ORDER BY id_user DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td> <?php echo $show->id_user; ?></td>
                    <td> <?php echo $show->nome; ?></td>
                    <td> <?php echo $show->email; ?></td>
                    <td> <?php echo $show->senha; ?></td>
                    <td> <?php echo $show->telefone; ?></td>
                   
                    <td>
               <a href="home.php?acaoadmin=Edituser&editar=<?php echo $show->id_user; ?>" class="btn btn-primary" data-dismiss="modal" title="Atualizar">
                                              <i class="far fa-edit"></i>
                                            </a></td>
       <td><a href="paginas/delete/delete.php?idDel5=<?php echo $show->id_user; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                    </td>
                    
                  </tr>
                 <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há Materiais cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>

      </div>
      <!-- /.container-fluid -->
       