<div id="content-wrapper">

      <div class="container-fluid">
       <ol class="breadcrumb">
          <li class="breadcrumb-item active">Slide</li>
        </ol>
        <hr>
  <div class="row">
  <div class="col-lg-12">
  <div class="card">
  <div class="card-body">
   <div class="row">

     <div class="col-lg-12">
      <?php
                              $id = filter_input(INPUT_GET, 'editar', FILTER_DEFAULT);

                              //echo $id;
                              $select = "SELECT * FROM tb_slide WHERE id_slide = :id";

                              try {
                                $resultado = $con->prepare($select);
                                $resultado->bindParam(':id', $id, PDO::PARAM_INT);
                                $resultado->execute();
                                //CONTA REGISTRO
                                $contar = $resultado->rowCount();
                                if ($contar > 0) {
                                  while ($show = $resultado->FETCH(PDO::FETCH_OBJ)){
                                      $id = $show->id_slide;
                                      $img = $show->img_slide;
                                      $nome = $show->nome_slide;
                                      $link= $show->link;
                                  }
                                }else {
                                  echo '<div class="alert alert-danger"><strong>Aviso!</strong> Não há dados com id(parâmetro) informado :(</div>';
                                }
                              } catch (PDOException $e) {
                                echo "<b>ERRO DE PDO NO SELECT: </b>".$e->getMessage();
                              }

                            ?>
      <form method="post"  enctype="multipart/form-data">
       <div class="form-group">
         <label for="slide">Imagem</label>
        <input type="file" class="form-control" name="slide[]" placeholder="Insira uma foto de Novidade..." id="slide"                   value="<?php echo $img; ?>" maxlength="100">

       </div>
        <div class="form-group">
         <label for="titulo">Titulo</label>
          <input type="text" class="form-control" name="titulo" id="titulo" value="<?php echo $nome; ?>" >
       </div>
       <div class="form-group">
         <label for="titulo">Link</label>
          <input type="text" class="form-control" name="link" id="link" value="<?php echo $link; ?>" >
       </div>
       <div class="row">
       <div class="col-lg-6">
         <button class="btn btn-success" type="submit" name="editar">Editar</button>
       </div>
         </div>
          </div>
        </form>
         <?php
                      //Atualizando dados
                      $novoNome = $img;
                        if (isset($_POST['editar'])) {
                          $nome  = filter_input(INPUT_POST, 'titulo' ,FILTER_DEFAULT);
                          $link  = filter_input(INPUT_POST, 'link' ,FILTER_DEFAULT);
                          $img  = filter_input(INPUT_POST, 'slide' ,FILTER_DEFAULT);
                         

                  //INFO IMAGEM
                               if (!empty($_FILES['slide']['name'])) {
                              $file     = $_FILES['slide'];
                              $numFile  = count(array_filter($file['name']));

                              //PASTA
                              $folder   = 'img/slide';

                              //REQUISITOS
                              $permite  = array('image/jpeg', 'image/png', 'image/jpg', 'image/gif');
                              $maxSize  = 1024 * 1024 * 5;

                              //MENSAGENS
                              $msg    = array();
                              $errorMsg = array(
                                1 => 'O arquivo no upload é maior do que o limite definido em upload_max_filesize no php.ini.',
                                2 => 'O arquivo ultrapassa o limite de tamanho em MAX_FILE_SIZE que foi especificado no formulário HTML',
                                3 => 'o upload do arquivo foi feito parcialmente',
                                4 => 'Não foi feito o upload do arquivo'
                              );

                              if($numFile <= 0){
                                // echo '<div class="alert alert-danger">
                                //       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                //       Selecione uma fotos para o contato!
                                //     </div>';
                              }
                              else if($numFile >=2){
                                echo '<div class="alert alert-danger">
                                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                      Seu limite e de uma foto apenas.
                                    </div>';
                              }else{
                                for($i = 0; $i < $numFile; $i++){
                                  $name   = $file['name'][$i];
                                  $type = $file['type'][$i];
                                  $size = $file['size'][$i];
                                  $error  = $file['error'][$i];
                                  $tmp  = $file['tmp_name'][$i];

                                  $extensao = @end(explode('.', $name));
                                  $novoNome = rand().".$extensao";

                                  if($error != 0)
                                    $msg[] = "<b>$name :</b> ".$errorMsg[$error];
                                  else if(!in_array($type, $permite))
                                    $msg[] = "<b>$name :</b> Erro imagem não suportada!";
                                  else if($size > $maxSize)
                                    $msg[] = "<b>$name :</b> Erro imagem ultrapassa o limite de 2MB";
                                  else{

                                    if(move_uploaded_file($tmp, $folder.'/'.$novoNome)){

                                    }else
                                      $msg[] = "<b>$name :</b> Desculpe! Ocorreu um erro dados não enviados...";

                                  }

                                  foreach($msg as $pop)
                                  echo '';
                                }
                              }

                            }else{
                              $novoNome = $img;
                            }
                                  //QUERY DE UPDATE
                          $update = "UPDATE tb_slide SET img_slide=:slide, nome_slide=:titulo, link=:link WHERE id_slide = :id";
                          try{
                            $result = $con->prepare($update);
                            $result ->bindValue(':id'     ,$id      ,PDO::PARAM_INT);
                            $result ->bindValue(':slide'    ,$novoNome,PDO::PARAM_STR);
                            $result ->bindValue(':titulo'   ,$nome    ,PDO::PARAM_STR);
                            $result ->bindValue(':link'   ,$link    ,PDO::PARAM_STR);
                            $result ->execute();

                            $contar = $result->rowCount();
                            if ($contar>0) {
                                        echo "<div  class='alert alert-success' role='alert'>
                                        <button sytle='margin-top:10px;' type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                                        <strong>Atualizado com sucesso!</strong> <i class='fa fa-check-circle'></i>
                                        </div>";
                                        header("Refresh:2, home.php?acaoadmin=Slide");
                                      }else{
                                        echo "<div class='alert alert-danger' role='alert'>
                                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                                        <strong>Erro ao Atualizar!</strong> <i class='fa fa-times'></i>
                                        </div>";
                                        #header("Location: ../home.php?acaoadmin=Slide");
                                      }
                                    }catch(PDOException $e){
                                      echo "<b>ERRO DE UPDATE: </b>".$e->getMessage();
                                    }
                              }
                       ?>
      
</div>
</div>
</div>
</div>
</div>

<br>
<!-- DataTables Example -->
        </div>