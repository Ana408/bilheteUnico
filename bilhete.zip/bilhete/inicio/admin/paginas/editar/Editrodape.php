 <div id="content-wrapper">

      <div class="container-fluid">
<ol class="breadcrumb">
          <li class="breadcrumb-item active">Rodapé</li>
        </ol>

       
        <hr>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<div class="row">

     <div class="col-lg-6">
        <?php
                              $id = filter_input(INPUT_GET, 'editar', FILTER_DEFAULT);

                              //echo $id;
                              $select = "SELECT * FROM tb_rodape WHERE id_rodape = :id";

                              try {
                                $resultado = $con->prepare($select);
                                $resultado->bindParam(':id', $id, PDO::PARAM_INT);
                                $resultado->execute();
                                //CONTA REGISTRO
                                $contar = $resultado->rowCount();
                                if ($contar > 0) {
                                  while ($show = $resultado->FETCH(PDO::FETCH_OBJ)){
                                      $id = $show->id_rodape;
                                      $titu = $show->titulo;
                                      $des = $show->des;
                                      $hora = $show->horario;
                                      $horario = $show->hora_fecha;
                                      $end = $show->endereco;
                                      $tele= $show->telefone;
                                      
                                      
                                  }
                                }else {
                                  echo '<div class="alert alert-danger"><strong>Aviso!</strong> Não há dados com id(parâmetro) informado :(</div>';
                                }
                              } catch (PDOException $e) {
                                echo "<b>ERRO DE PDO NO SELECT: </b>".$e->getMessage();
                              }

                            ?>
      <form  method="post">
       <div class="form-group">
         <label for="titulo">Titulo (Descrição)</label>
        <input type="text" class="form-control" name="titulo" id="titulo" value="<?php echo $titu; ?>" maxlength="100">
       </div>
        <div class="form-group">
         <label for="desc1">Descrição</label>
          <textarea class="form-control" name="des" id="des" value="<?php echo $des; ?>"></textarea>
       </div>
        <div class="form-group">
         <label for="hora">Horário de Abertura</label>
          <input type="text" class="form-control" name="hora" id="hora" value="<?php echo $hora; ?>" maxlength="100">
       </div>
       <div class="form-group">
         <label for="horaE">Hora de Encerrar</label>
          <input type="text" class="form-control" name="horaE" id="horaE" value="<?php echo $horario; ?>" maxlength="100">
       </div>
        <div class="form-group">
         <label for="endereco">Endereço</label>
          <input type="text" class="form-control" name="endereco" id="endereco" value="<?php echo $end; ?>" maxlength="100">
       </div>
        <div class="form-group">
         <label for="telefone">Telefone</label>
          <input type="text" class="form-control" name="telefone" id="telefone" value="<?php echo $tele; ?>" maxlength="100">
       </div>
       
        <div class="row">
       <div class="col-lg-4">
         <button class="btn btn-success" type="submit" name="rodape">Editar</button>
       </div></div>
        </form>
           <?php
                      //Atualizando dados
                        if (isset($_POST['rodape'])) {
                          $titu  = filter_input(INPUT_POST, 'titulo' ,FILTER_DEFAULT);
                          $desc = filter_input(INPUT_POST, 'des',FILTER_DEFAULT);
                          $hora  = filter_input(INPUT_POST, 'hora'  ,FILTER_DEFAULT);
                          $horario = filter_input(INPUT_POST, 'horaE' ,FILTER_DEFAULT);
                          $end  = filter_input(INPUT_POST, 'endereco'  ,FILTER_DEFAULT);
                          $tele  = filter_input(INPUT_POST, 'telefone'  ,FILTER_DEFAULT);
                         
                                  //QUERY DE UPDATE
                          $update = "UPDATE tb_rodape SET titulo=:titulo, des=:des, horario=:hora, hora_fecha=:horaE,endereco=:endereco, telefone=:telefone WHERE id_rodape = :id";
                          try{
                            $result = $con->prepare($update);
                            $result ->bindValue(':id'     ,$id      ,PDO::PARAM_INT);
                            $result ->bindValue(':titulo'   ,$titu    ,PDO::PARAM_STR);
                            $result ->bindValue(':des',$des ,PDO::PARAM_STR);
                            $result ->bindValue(':hora'  ,$hora   ,PDO::PARAM_STR);
                            $result ->bindValue(':horaE'  ,$horario   ,PDO::PARAM_STR);
                            $result ->bindValue(':endereco'  ,$end   ,PDO::PARAM_STR);
                             $result ->bindValue(':telefone'  ,$tele   ,PDO::PARAM_STR);
                              
                            $result ->execute();
                           
                            $contar = $result->rowCount();
                            if ($contar>0) {
                                        echo "<div class='alert alert-success' role='alert'>
                                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                                        <strong>Atualizado com sucesso!</strong> <i class='fa fa-check-circle'></i>
                                        </div>";
                                        header("Refresh:2, home.php?acaoadmin=rodape");
                                      }else{
                                        echo "<div class='alert alert-danger' role='alert'>
                                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                                        <strong>Erro ao Atualizar!</strong> <i class='fa fa-times'></i>
                                        </div>";
                                        #header("Location: home.php?acaoadmin=usercad");
                                      }
                                    }catch(PDOException $e){
                                      echo "<b>ERRO DE UPDATE: </b>".$e->getMessage();
                                    }
                              }
                       ?> 

                    
                    
                    
                       
     
     
</div>
</div>
</div>
</div>
</div>
</div>


 <br>  
       


      </div>
    </div>
      <!-- /.container-fluid -->