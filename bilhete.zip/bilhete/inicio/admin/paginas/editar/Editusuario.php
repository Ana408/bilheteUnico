 <div id="content-wrapper">

      <div class="container-fluid">
<ol class="breadcrumb">
          <li class="breadcrumb-item active">Usuários</li>
        </ol>

       
        <hr>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<div class="row">

     <div class="col-lg-6">
      <?php
                              $id = filter_input(INPUT_GET, 'editar', FILTER_DEFAULT);

                              //echo $id;
                              $select = "SELECT * FROM tb_user WHERE id_user = :id";

                              try {
                                $resultado = $con->prepare($select);
                                $resultado->bindParam(':id', $id, PDO::PARAM_INT);
                                $resultado->execute();
                                //CONTA REGISTRO
                                $contar = $resultado->rowCount();
                                if ($contar > 0) {
                                  while ($show = $resultado->FETCH(PDO::FETCH_OBJ)){
                                      $id = $show->id_user;
                                      $nome = $show->nome;
                                      $email = $show->email;
                                      $senha = $show->senha;
                                      $tele = $show->telefone;
                                      
                                      
                                  }
                                }else {
                                  echo '<div class="alert alert-danger"><strong>Aviso!</strong> Não há dados com id(parâmetro) informado :(</div>';
                                }
                              } catch (PDOException $e) {
                                echo "<b>ERRO DE PDO NO SELECT: </b>".$e->getMessage();
                              }

                            ?>
      <form  method="post">
       <div class="form-group">
         <label for="nome">Nome</label>
        <input type="text" class="form-control" name="nome" id="nome" value="<?php echo $nome; ?>" maxlength="100">
       </div>
        <div class="form-group">
         <label for="email">E-mail</label>
          <input class="form-control" name="email" id="email" value="<?php echo $email; ?>"></input>
       </div>
        <div class="form-group">
         <label for="telefone">Telefone</label>
          <input type="text" class="form-control" name="telefone" id="telefone" value="<?php echo $tele; ?>" maxlength="100">
       </div>
       <div class="form-group">
         <label for="senha">Senha</label>
          <input type="password" class="form-control" name="senha" id="senha" value="<?php echo $senha; ?>" maxlength="100">
       </div>
        <div class="row">
       <div class="col-lg-4">
         <button class="btn btn-success" type="submit" name="user">Enviar</button>
       </div></div>
        </form>
        <?php
                      //Atualizando dados
                        if (isset($_POST['user'])) {
                          $nome  = filter_input(INPUT_POST, 'nome' ,FILTER_DEFAULT);
                          $email = filter_input(INPUT_POST, 'email',FILTER_DEFAULT);
                          $senha  = filter_input(INPUT_POST, 'senha'  ,FILTER_DEFAULT);
                          $tele = filter_input(INPUT_POST, 'telefone' ,FILTER_DEFAULT);
                          
                                  //QUERY DE UPDATE
                          $update = "UPDATE tb_user SET nome=:nome, email=:email, senha=:senha, telefone=:telefone WHERE id_user = :id";
                          try{
                            $result = $con->prepare($update);
                            $result ->bindValue(':id'     ,$id      ,PDO::PARAM_INT);
                            $result ->bindValue(':nome'   ,$nome    ,PDO::PARAM_STR);
                            $result ->bindValue(':email',$email ,PDO::PARAM_STR);
                            $result ->bindValue(':senha'  ,$senha   ,PDO::PARAM_STR);
                            $result ->bindValue(':telefone'  ,$tele   ,PDO::PARAM_STR);
                            
                            $result ->execute();
                           
                            $contar = $result->rowCount();
                            if ($contar>0) {
                                        echo "<div class='alert alert-success' role='alert'>
                                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                                        <strong>Atualizado com sucesso!</strong> <i class='fa fa-check-circle'></i>
                                        </div>";
                                         header("Refresh:1, home.php?acaoadmin=user");
                                      }else{
                                        echo "<div class='alert alert-danger' role='alert'>
                                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                                        <strong>Erro ao Atualizar!</strong> <i class='fa fa-times'></i>
                                        </div>";
                                        #header("Location: home.php?acaoadmin=usercad");
                                      }
                                    }catch(PDOException $e){
                                      echo "<b>ERRO DE UPDATE: </b>".$e->getMessage();
                                    }
                              }
                       ?> 
                              <!-- Fim Cadastro PHP -->

                    
                    
                    
                       
     
     
</div>
</div>
</div>
</div>
</div>
</div>


 <br>  
        
          
        </div>


      </div>
      <!-- /.container-fluid -->