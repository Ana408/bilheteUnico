

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
           Principal
          </li>
         
        </ol>
           
        

            <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Usuários</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Senha</th>
                    <th>Remover</th>
                  </tr>
                </thead>
                <tbody>
                   <?php
                $select = "SELECT * FROM tb_cad ORDER BY id_cad DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td><?php echo $show->id_cad; ?></td>
                    <td><?php echo $show->nome_cad; ?>"</td>
                    <td><?php echo $show->email_cad; ?></td>
                    <td><?php echo $show->senha; ?></td>
                     
       <td><a href="paginas/delete/delete.php?idDel3=<?php echo $show->id_sistema; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                    
                    
                  </tr>
                 <?php
              }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Slide</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Imagem</th>
                    <th>Nome (Sistemas)</th>
                    <th>Link</th>
                    <th>Editar</th>
                    <th>Remover</th>
                  </tr>
                </thead>
               <tbody>
                <?php
                $select = "SELECT * FROM tb_slide ORDER BY id_slide DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td><?php echo $show->id_slide; ?></td>
                    <td><img src="img/slide/<?php echo $show->img_slide; ?>" style="width:90px"/></td>
                    <td><?php echo $show->nome_slide; ?></td>
                    <td><?php echo $show->link; ?></td>
                      <td>
              <a href="home.php?acaoadmin=UpSlide&editar=<?php echo $show->id_slide; ?>" class="btn btn-primary" data-dismiss="modal" title="Atualizar">
                                              <i class="far fa-edit"></i>
                                            </a></td>
       <td><a href="paginas/delete/delete.php?idDel=<?php echo $show->id_slide; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                    </td>
                  </tr>
                 <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
        </div>
 <br>
 <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Descrição</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Imagem</th>
                    <th>Titulo</th>
                    <th>Descrição</th>
                    <th>Editar</th>
                    <th>Remover</th>
                     </tr>
                </thead>
               <tbody>
                 <?php
                $select = "SELECT * FROM tb_desc ORDER BY id_desc DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td><?php echo $show->id_desc; ?></td>
                    <td><img src="img/descricao/<?php echo $show->img_desc; ?>" style="width:130px"/></td>
                    <td><?php echo $show->titulo_desc; ?></td>
                    <td><?php echo $show->descr; ?></td>
                    <td>
              <a href="home.php?acaoadmin=Updesc&editar=<?php echo $show->id_desc; ?>" class="btn btn-primary" data-dismiss="modal" title="Atualizar">
                                               <i class="far fa-edit"></i>
                                            </a></td>
       <td><a href="paginas/delete/delete.php?idDel2=<?php echo $show->id_desc; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                    
                  </tr>
                 <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há dados cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
      <br>     

      <br>  
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Rodapé</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Titulo (Descrição)</th>
                    <th>Descrição</th>
                    <th>Horário de Abertura</th>
                     <th>Horário de Encerrar</th>
                    <th>Endereço</th>
                    <th>Telefone</th>
                    
                    <th>Editar</th>
                    <th>Remover</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                $select = "SELECT * FROM tb_rodape ORDER BY id_rodape DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td> <?php echo $show->id_rodape; ?></td>
                    <td> <?php echo $show->titulo; ?></td>
                    <td> <?php echo $show->des; ?></td>
                    <td> <?php echo $show->horario; ?></td>
                    <td> <?php echo $show->hora_fecha; ?></td>
                    <td> <?php echo $show->endereco; ?></td>
                    <td> <?php echo $show->telefone; ?></td>
                    
                    <td>
                           <a href="home.php?acaoadmin=Uprodape&editar=<?php echo $show->id_rodape; ?>" class="btn btn-primary" title="Atualizar">
                                              <i class="far fa-edit"></i>
                                            </a></td>
      <td><a href="paginas/delete/delete.php?idDel4=<?php echo $show->id_rodape; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                   
                    
                  </tr>
                 <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há Materiais cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
          <br>
          <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Usuários</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Senha</th>
                     <th>Telefone</th>
                    <th>Editar</th>
                    <th>Remover</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                $select = "SELECT * FROM tb_user ORDER BY id_user DESC";
                $contagem = 1;
                try{
                  $result = $con->prepare($select);
                  $result->execute();
                  //contar os registros cadastrados na tabela tb_contato
                  $contar = $result->rowCount();
                  //condição para a exibição dos registros;
                  if ($contar>0) {
                    while ($show = $result->FETCH(PDO::FETCH_OBJ)) {

                    ?>
                  <tr>
                    <td> <?php echo $show->id_user; ?></td>
                    <td> <?php echo $show->nome; ?></td>
                    <td> <?php echo $show->email; ?></td>
                    <td> <?php echo $show->senha; ?></td>
                    <td> <?php echo $show->telefone; ?></td>
                   
                   
                     <td>
               <a href="home.php?acaoadmin=Edituser&editar=<?php echo $show->id_user; ?>" class="btn btn-primary" data-dismiss="modal" title="Atualizar">
                                              <i class="far fa-edit"></i>
                                            </a></td>
      <td><a href="paginas/delete/delete.php?idDel5=<?php echo $show->id_user; ?>" onclick="return confirm('Deseja Apagar este material?')" class="btn btn-danger"><i class=" fa fa-trash"></i></a></td>
                   
                    
                  </tr>
                 <?php
              
              

                  }
                  }else{
                    echo '<div class="alert alert-danger"><button type ="button" class="close" data-dismiss="alert">x</button><strong>Aviso!</strong> Não há Materiais cadastrados :(</div';
                  }
                }catch(PDOException $e){
                  echo "<b>Erro de select do PDO</b>".$e->getMessage();
                }
                ?>
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
        </div>
        

      </div>
      </div>
      <!-- /.container-fluid -->