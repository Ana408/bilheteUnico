<?php include_once('config/config.php');

  ob_start();
  session_start();
  if (!isset($_SESSION['loginUser']) && (!isset($_SESSION['senhaUser']))) {
    header("Location: ../index.php");
    exit;
  }
 include_once('../sair.php'); 
 ?>
<!DOCTYPE html>
<html lang="pt-BR utf-8">

<head>
  <?php include_once('config/config.php'); ?>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Administrador</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/fontawesome.2-web/css/all.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
<!-- Script do relogio -->
  <script type="text/javascript">
  function relogio() {
    var data = new Date();
    var horas = data.getHours();
    var minutos = data.getMinutes();
    var segundos = data.getSeconds();

    if(horas < 10){
      horas = "0"+horas;
    }
    if(minutos < 10){
      minutos = "0"+minutos;
    }
    if(segundos < 10){
      segundos = "0"+segundos;
    }
    document.getElementById("relogio").innerHTML=horas+":"+minutos+":"+segundos;
  }
  window.setInterval("relogio()",1000);
  </script>
  <!-- CSS do relogio -->
  <style type="text/css">
#relogio{
  font-size: 25px;
  width: 90px;
  color:#fff;
  font:bold 100px Arial:
  padding: 50px;
}
  </style>
  
</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-success static-top">

    <a class="navbar-brand mr-1" href="home.php">Administrador</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>

    <div style="margin-left: 880px;" class="navbar-btn navbar-btn-right">
          <div id="relogio"></div>
        </div>

    <!-- Navbar -->
    <ul  class="navbar-nav ml-auto ml-md-0">

      <li class="nav-item dropdown no-arrow" style="margin-left: 80px;">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>
        </a>
        <div  class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
         
          <a class="dropdown-item"  href="?sair">Sair</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="home.php?acaoadmin=principal">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Inicio</span>
        </a>
      </li>
      
     <li class="sidebar nav-item active dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Cadrastros</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
         <a class="dropdown-item" href="home.php?acaoadmin=Slide">
            Slide
          </a>
          <a class="dropdown-item" href="home.php?acaoadmin=desc">
          Descrição
          </a>
          <a class="dropdown-item" href="home.php?acaoadmin=sistema">
          Cadrastros
          </a>
           <a class="dropdown-item" href="home.php?acaoadmin=rodape">
          Rodapé
          </a>
         <a class="dropdown-item" href="home.php?acaoadmin=user">
          Usuários
          </a>
      </li>
     
    </ul>