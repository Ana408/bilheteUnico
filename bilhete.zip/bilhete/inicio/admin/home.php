<?php
/* Topo do ADMIN */
include_once('include/topo.php');
/* Corpo do ADMIN */
if (isset($_GET['acaoadmin'])) {
  $acao = $_GET['acaoadmin'];

  if ($acao == 'principal'){
    include_once('paginas/principal.php');

  }elseif ($acao == 'Slide') {
    include_once('paginas/slide.php');
  }elseif ($acao == 'UpSlide') {
    include_once('paginas/editar/Editslide.php');
  }elseif ($acao == 'desc') {
    include_once('paginas/desc.php');
  }elseif ($acao == 'Updesc') {
    include_once('paginas/editar/Editdesc.php');
  }elseif ($acao == 'sistema') {
    include_once('paginas/sistema.php');
  }elseif ($acao == 'Upsis') {
    include_once('paginas/editar/Editsistema.php');
  }elseif ($acao == 'Uprodape') {
    include_once('paginas/editar/Editrodape.php');
  }elseif ($acao == 'rodape') {
    include_once('paginas/rodape.php');
  }elseif ($acao == 'user') {
    include_once('paginas/usuario.php');
  }elseif ($acao == 'Edituser') {
    include_once('paginas/editar/Editusuario.php');
  }
}else{
   include_once('paginas/principal.php');
}


/* Rodapé do ADMIN */
include_once('include/rodape.php');
