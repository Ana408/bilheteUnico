
<?php
  include_once('admin/config/config.php');
 ?>
 <?php
  ob_start(); //Armazena no cache
  session_start(); // Inicia a sessão
  if (isset($_SESSION['loginUser']) && (isset($_SESSION['senhaUser']))) {
    header("Location: admin/home.php");
    exit;
}
?>
<!doctype html>
<html lang="pt-Br utf-8" class="fullscreen-bg">

<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <!-- VENDOR CSS -->
  <link rel="stylesheet" href="admin/login/assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="admin/login/assets/vendor/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="admin/login/assets/vendor/linearicons/style.css">
  <!-- MAIN CSS -->
  <link rel="stylesheet" href="admin/login/assets/css/main.css">
  <!-- GOOGLE FONTS -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
  <!-- ICONS -->
  <link rel="icon" type="image/png" sizes="96x96" href="">
</head>

<body style="background-color:#08863d;">
  <!-- WRAPPER -->
  <div id="wrapper">
    <div class="vertical-align-wrap">
      <div class="vertical-align-middle">
        <div class="auth-box">
          <div class="left">
            <div class="content">
              <div class="header">
                <div class="logo text-center" style="margin-bottom:25px;">
                  <img src="admin/img/unnamed.png" width="30%;">
                </div>
                <p class="lead">Entre na sua Conta</p>
              </div>
              <form class="form-auth-small" method="post" action="">
                <div class="form-group input-group">
                  <label for="signin-email" class="control-label sr-only">Email</label>
                  <input type="email" class="form-control" id="signin-email" name="emailLogin" placeholder="Digite seu Email">
                  <span class="input-group-addon"><i class="fa fa-user"></i></span>
                </div>
                <div class="form-group input-group">
                  <label for="signin-password" class="control-label sr-only">Senha</label>
                  <input type="password" class="form-control" id="password" name="senhaLogin" placeholder="Digite sua Senha ">
                  <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                </div>
                   
                <p><a href="../index.php" style="color: #08863d; margin-top: "><i class="fa fa-users"></i>Voltar</a></p>
               
                <button style="background-color:#08863d;border-color: #08863d;" type="submit" class="btn btn-primary btn-lg btn-block" name="login">LOGIN</button>
             
                
                  
                <?php $estiloLogin = " "; $textoLogin = " "; ?>
              <?php
                  if (isset($_GET['acao'])) {
                    if (!isset($_POST['login'])){
                      $acao = $_GET['acao'];
                      if ($acao == 'negado') {
                        echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button><strong>Erro ao Acessar o sistema!</strong> Efetue o login ;(</div>';
                      }
                    }
                  }
                  if (isset($_POST['login'])){
                    $login = filter_input(INPUT_POST, 'emailLogin', FILTER_DEFAULT);
                    $senha = filter_input(INPUT_POST, 'senhaLogin', FILTER_DEFAULT);
                    
                    $select = "SELECT * FROM tb_user WHERE email=:emailLogin AND senha=:senhaLogin";

                    try {
                      $resultLogin = $con->prepare($select);
                      $resultLogin->bindParam(':emailLogin',$login, PDO::PARAM_STR);
                      $resultLogin->bindParam(':senhaLogin',$senha, PDO::PARAM_STR);
                      
                      $resultLogin->execute();

                      $verificar = $resultLogin->rowCount();
                      if ($verificar > 0) {
                        $login = $_POST['emailLogin'];
                        $senha = $_POST['senhaLogin'];

                        //CRIANDO A SESSÃO DE LOGIN E SENHA
                        $_SESSION['loginUser'] = $login;
                        $_SESSION['senhaUser'] = $senha;

                        echo'<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">X</button>
                        LOGADO COM SUCESSO</div>';
                        header("Refresh:1, admin/home.php?acaoadmin=principal");
                        


                      }else{
                       echo'<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">X</button>
                        ERRO AO LOGAR</div>';
                        header("Refresh:1, admin/home.php?acaoadmin=principal");

                      }
                    } catch (PDOException $e){
                      echo "ERRO DE LOGIN DO PDO : ".$e->getMessage();
                    }
                  }
                ?>
                <div class="bottom">
                  <span class="helper-text <?php echo $estiloLogin; ?>"><?php echo $textoLogin; ?></span>
                </div>
              </form>
            </div>
          </div>

          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
  <!-- END WRAPPER -->
  <script type="text/javascript" src="admin/login/assets/vendor/jquery/jquery.min.js"></script>
  <script type="text/javascript">
  $(document).ready(function(){
  $('#showPassword').on('click', function(){

    var passwordField = $('#password');
    var passwordFieldType = passwordField.attr('type');
    if(passwordFieldType == 'password')
    {
        passwordField.attr('type', 'text');
        $(this).val('Hide');
    } else {
        passwordField.attr('type', 'password');
        $(this).val('Show');
    }
  });
  });
  </script>
</body>

</html>
