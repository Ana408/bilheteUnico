-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 23-Jun-2021 às 02:43
-- Versão do servidor: 10.4.19-MariaDB
-- versão do PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bd_inicial`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cad`
--

CREATE TABLE `tb_cad` (
  `id_cad` int(11) NOT NULL,
  `nome_cad` varchar(100) NOT NULL,
  `email_cad` varchar(100) NOT NULL,
  `senha` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_cad`
--

INSERT INTO `tb_cad` (`id_cad`, `nome_cad`, `email_cad`, `senha`) VALUES
(1, 'Ana Karine Nobre Bezerra', 'karinebezerra0615@gmail.com', '161524'),
(2, 'Ana Karine Nobre Bezerra', '2017infor04@gmail.com', '16152414');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_desc`
--

CREATE TABLE `tb_desc` (
  `id_desc` int(11) NOT NULL,
  `img_desc` varchar(250) NOT NULL,
  `titulo_desc` varchar(15) NOT NULL,
  `descr` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_desc`
--

INSERT INTO `tb_desc` (`id_desc`, `img_desc`, `titulo_desc`, `descr`) VALUES
(2, '981702300.jpg', 'Bilhete Único', 'O Bilhete Único Fortaleza é o atual modelo de integração utilizado no transporte coletivo de Fortaleza. Com ele é possível pegar quantos ônibus quiser, no período de duas horas, em qualquer sentido, pagando apenas uma passagem ou meia passagem, no caso dos estudantes. Com o Bilhete Único o passageiro fica livre para fazer o embarque e desembarque na parada em que desejar, sem ter a obrigatoriedade de passar por um terminal.');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_rodape`
--

CREATE TABLE `tb_rodape` (
  `id_rodape` int(11) NOT NULL,
  `titulo` text NOT NULL,
  `des` longtext NOT NULL,
  `horario` time NOT NULL,
  `hora_fecha` time NOT NULL,
  `endereco` varchar(250) NOT NULL,
  `telefone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_rodape`
--

INSERT INTO `tb_rodape` (`id_rodape`, `titulo`, `des`, `horario`, `hora_fecha`, `endereco`, `telefone`) VALUES
(4, 'Bilhete Único', 'O Bilhete Único Fortaleza é o atual modelo de integração utilizado no transporte coletivo de Fortaleza. Com ele é possível pegar quantos ônibus quiser, no período de duas horas, em qualquer sentido, pagando apenas uma passagem ou meia passagem, no caso dos estudantes. Com o Bilhete Único o passageiro fica livre para fazer o embarque e desembarque na parada em que desejar, sem ter a obrigatoriedade de passar por um terminal', '08:00:00', '16:00:00', 'Sindiônibus - Avenida Borges de Melo - Aerolândia, Fortaleza - CE', '33480527');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_sistemas`
--

CREATE TABLE `tb_sistemas` (
  `id_sistema` int(11) NOT NULL,
  `img_sis` varchar(250) NOT NULL,
  `link` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_sistemas`
--

INSERT INTO `tb_sistemas` (`id_sistema`, `img_sis`, `link`) VALUES
(8, '1058244645.png', 'Libras'),
(9, '210470387.png', 'almoxarifado'),
(10, '543471883.png', 'SADE');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_slide`
--

CREATE TABLE `tb_slide` (
  `id_slide` int(11) NOT NULL,
  `img_slide` varchar(250) NOT NULL,
  `nome_slide` varchar(50) NOT NULL,
  `link` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_slide`
--

INSERT INTO `tb_slide` (`id_slide`, `img_slide`, `nome_slide`, `link`) VALUES
(8, '2131782155.jpg', 'Bilhete Único', 'aaa'),
(9, '964369999.jpg', 'Bilhete Único', 'aa');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nome`, `email`, `senha`, `telefone`) VALUES
(3, 'Tadeu', 'tadeu@sindiônibus.com', 'suporte', '(99)999999999'),
(4, 'Matheus Lopes', 'matheus@sindiônibus.com', 'suporte', '(99)999999999');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_cad`
--
ALTER TABLE `tb_cad`
  ADD PRIMARY KEY (`id_cad`);

--
-- Índices para tabela `tb_desc`
--
ALTER TABLE `tb_desc`
  ADD PRIMARY KEY (`id_desc`);

--
-- Índices para tabela `tb_rodape`
--
ALTER TABLE `tb_rodape`
  ADD PRIMARY KEY (`id_rodape`);

--
-- Índices para tabela `tb_sistemas`
--
ALTER TABLE `tb_sistemas`
  ADD PRIMARY KEY (`id_sistema`);

--
-- Índices para tabela `tb_slide`
--
ALTER TABLE `tb_slide`
  ADD PRIMARY KEY (`id_slide`);

--
-- Índices para tabela `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_cad`
--
ALTER TABLE `tb_cad`
  MODIFY `id_cad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_desc`
--
ALTER TABLE `tb_desc`
  MODIFY `id_desc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_rodape`
--
ALTER TABLE `tb_rodape`
  MODIFY `id_rodape` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_sistemas`
--
ALTER TABLE `tb_sistemas`
  MODIFY `id_sistema` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `tb_slide`
--
ALTER TABLE `tb_slide`
  MODIFY `id_slide` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
